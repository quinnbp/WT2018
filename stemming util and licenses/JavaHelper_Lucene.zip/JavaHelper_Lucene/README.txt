This ZIP file contains a copy of two of the JAR files from the open source Lucene 6.2.1 project by Apache for use in Homework 2 of CSCI 374.  The original project can be found at https://lucene.apache.org/

Lucent is released under the Apache 2.0 license.  All credit to Apache for these libraries.