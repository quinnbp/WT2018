This ZIP file contains a copy of the open source NLTK 3.2.1 for use in Homework 2 of CSCI 374.  The original project can be found at http://www.nltk.org/

The ZIP file also contains a copy of the english.pickle tokenizer by punkt (which can be downloaded separately using NLTK’s downloading function nltk.download(“punkt”)). 

NLTK is released under the Apache 2.0 license.  All credit to NLTK for this library, and all credit to punkt for the tokenizer. 