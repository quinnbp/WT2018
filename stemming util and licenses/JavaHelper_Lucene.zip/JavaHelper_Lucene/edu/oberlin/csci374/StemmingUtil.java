package edu.oberlin.csci374;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.util.AttributeFactory;
import org.tartarus.snowball.ext.EnglishStemmer;

/**
 * The {@link StemmingUtil} class provides a set of static utility methods for
 * analyzing text.  In particular, it uses the Lucene library from Apache
 * to provide support for (1) parsing a string of text into individual
 * tokens (e.g., words), and (2) finding the stem of each token from a list
 * of tokens.
 * 
 * @author Adam Eck
 */
public class StemmingUtil {
    /**
     * Parses a string of text into a ordered list of individual tokens, each
     * representing a different word in the original text.
     * 
     * @param text The text to parse for tokens
     * 
     * @return An ordered list of tokens from {@code text}
     * 
     * @throws IOException In case there is a problem reading {@code text}
     */
    /* Credit to http://stackoverflow.com/questions/30523642/how-to-use-standardtokenizer-from-lucene-5-x-x
     * for details on how to tokenize a string with Lucene.
     */
    public static List<String> parseTokens(String text) throws IOException {
        List<String> tokens = new ArrayList<String>();
        
        StandardTokenizer tokenizer = new StandardTokenizer(
                AttributeFactory.DEFAULT_ATTRIBUTE_FACTORY);
        tokenizer.setReader(new StringReader(text));
        tokenizer.reset();

        CharTermAttribute attr = tokenizer.addAttribute(CharTermAttribute.class);
        while (tokenizer.incrementToken()) {
            tokens.add(attr.toString());
        }
        
        return tokens;
    }
    
    /**
     * Converts a list of tokens into a list of word stems, one per token.
     * 
     * Note: a stem for a word is the base of the word so that all variants of 
     * the same word (e.g., singular vs. plural nouns, conjugated verbs) share
     * the same stem.
     * 
     * @param tokens The list of tokens for which to create stems
     * 
     * @return A list of stems for {@code tokens} in the same order that they
     *      appear in the {@code tokens} list
     */    
    /* Credit to http://stackoverflow.com/questions/5391840/stemming-english-words-with-lucene
     * for details on how to find the stem of a word with Lucene.
     */    
    public static List<String> createStems(List<String> tokens) {
        // stem the tokens
        EnglishStemmer stemmer = new EnglishStemmer();
        List<String> stems = new ArrayList<String>();
        for (String token : tokens) {
            stemmer.setCurrent(token);
            stemmer.stem();
            stems.add(stemmer.getCurrent());
        }
        
        return stems;
    }    
}
